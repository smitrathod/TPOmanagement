﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_Users_LoginForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        SqlCommand cmd = new SqlCommand("SELECT * FROM [dbo].[MasterUser] WHERE UserName = @UserName and Password = @Password", objConnection);
        cmd.Parameters.AddWithValue("@UserName", txtUserName.Text);
        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);

        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);

        objConnection.Open();

        if(dt.Rows.Count > 0 && dt != null)
        {
            Session["UserName"] = txtUserName.Text.ToString();
            Response.Redirect("~/AdminPanel/Default.aspx");            
        }
        else
        {
            lblMessage.Text = "Username or Password is incorrect";
            lblMessage.ForeColor = Color.Red;
        }
    }
    protected void btnCancle_Click(object sender, EventArgs e)
    {
        txtUserName.Text = "";
        txtPassword.Text = "";
    }
    }