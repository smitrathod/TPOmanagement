﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_MasterUser_SignupForm : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnCreate_Click(object sender, EventArgs e)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();

        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;

        objCmd.CommandText = "PR_MasterUser_Insert";
        objCmd.Parameters.AddWithValue("@UserName", txtUserName.Text.ToString());
        objCmd.Parameters.AddWithValue("@Password", txtPassword.Text.ToString());
        objCmd.Parameters.AddWithValue("@FullName", txtFullName.Text.ToString());
        objCmd.Parameters.AddWithValue("@Address", txtAddress.Text.ToString());
        objCmd.Parameters.AddWithValue("@Email", txtEmail.Text.ToString());
        objCmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text.ToString());
        objCmd.Parameters.AddWithValue("@FacebookLogIn", txtFacebook.Text.ToString());
        objCmd.Parameters.AddWithValue("@BirthDate", txtBirthDate.Text.ToString());
        objCmd.ExecuteNonQuery();
        objConnection.Close();

        Response.Redirect("~/AdminPanel/MasterUser/LoginForm.aspx");
    }
}