﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_State_StateList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            lblUserSession.Text = "Welcome, " + Session["UserName"].ToString();
        }
        if (!Page.IsPostBack)
        {
            FillStateGridView();
        }

    }
    protected void gvState_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            DeleteState(Convert.ToInt32(e.CommandArgument));
            FillStateGridView();
        }

    }

    private void FillStateGridView()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        //objConnection.ConnectionString = "data source=JALPESH\\SQLEXPRESS;initial catalog=AddressBook; Integrated Security=true;";
        //objConnection.ConnectionString = ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString;
        objConnection.Open();
        // lblMessage.Text ="Connection Is Now Open";
        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.CommandText = "PR_State_SelectAll";
        objcmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
        SqlDataReader objSDR = objcmd.ExecuteReader();
        gvState.DataSource = objSDR;
        gvState.DataBind();
        objConnection.Close();

    }

    private void DeleteState(Int32 StateID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        try
        {
            objConnection.Open();
            SqlCommand objcmd = objConnection.CreateCommand();
            objcmd.CommandType = CommandType.StoredProcedure;
            objcmd.CommandText = "PR_State_DeleteByPK";
            objcmd.Parameters.AddWithValue("@StateID", StateID);
            objcmd.ExecuteNonQuery();
            objConnection.Close();
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
        finally
        {
            objConnection.Close();
        }

    }
}