﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class AdminPanel_State_StateAddEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["StateID"] != null)
            {
                LoadControl(Convert.ToInt32(Request.QueryString["StateID"]));
                lblPageHeader.Text = "State Edit";
            }
            else
            {
                lblPageHeader.Text = "State Add";
            }
        }
    }
    private void LoadControl(Int32 StateID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();

        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.CommandText = "PR_State_SelectByPK";
        objcmd.Parameters.AddWithValue("@StateID", StateID);

        SqlDataReader objSDR = objcmd.ExecuteReader();
        if (objSDR.HasRows == true)
        {
            while (objSDR.Read() == true)
            {
                if (!objSDR["StateName"].Equals(DBNull.Value))
                {
                    txtStateName.Text = objSDR["StateName"].ToString();

                }
                if (!objSDR["StateName"].Equals(DBNull.Value))
                {
                    txtCountryID.Text = objSDR["CountryID"].ToString();
                }
            }
        }






        objConnection.Close();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        SqlString strStateName = SqlString.Null;
        SqlString strCountryID = SqlString.Null;

        if (txtStateName.Text.Trim() != "")
            strStateName = txtStateName.Text.Trim();

        if (txtCountryID.Text.Trim() != "")
            strCountryID = txtCountryID.Text.Trim();


        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        // objConnection.ConnectionString = ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString;
        objConnection.Open();
        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.Parameters.AddWithValue("@StateName", strStateName);
        objcmd.Parameters.AddWithValue("@CountryID", strCountryID);

        if (Request.QueryString["StateID"] == null)
        {
            objcmd.CommandText = "PR_State_Insert";
            objcmd.Parameters.AddWithValue("@CreationDate", DateTime.Now);
            objcmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
        }
        else
        {
            objcmd.CommandText = "PR_State_UpdateByPK";
            objcmd.Parameters.AddWithValue("@StateID", Request.QueryString["StateID"].ToString());
        }

        objcmd.ExecuteNonQuery();
        objConnection.Close();



        if (Request.QueryString["StateID"] == null)
        {
            lblMessage.Text = "Data  Inserted Successfully........";
            txtStateName.Text = "";
            txtCountryID.Text = "";
            txtStateName.Focus();
            //lblMessage.Text = "";
        }
        else
        {
            Response.Redirect("~/AdminPanel/State/StateList.aspx");
        }

    }
}