﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class AdminPanel_City_CityList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserName"] != null)
        {
            lblUserSession.Text = "Welcome, " + Session["UserName"].ToString();
        }
        if (!Page.IsPostBack)
        {
            FillCityGridView();
        }
    }

    protected void gvCity_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            DeleteCity(Convert.ToInt32(e.CommandArgument));
            FillCityGridView();
        }
    }

    private void FillCityGridView()
    {
        //Step 1: Establish Connection
        //Connection
        SqlConnection objConnection = new SqlConnection();
        //DataSource = 01_17_06\SQL2014 (Sourece of Data, Name of Sql Server)
        //DatebaseName = AddressBook
        //Type Of Authentication (Windows/SQL)
        //If SQL - User ID, Password
        //objConnection.ConnectionString = "data source=01_17_06\\SQL2014;initial catalog=AddressBook; Integrated Security=true;";
        objConnection.ConnectionString = ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString;
        objConnection.Open();

        // lblMessage.Text = "Connection is now open";
        //Step 2.1: Create Command

        SqlCommand objCmd = new SqlCommand();
        objCmd.Connection = objConnection;
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_City_SelectAll";
        objCmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
        // objCmd.CommandText = "SELECT CityID, CityName, CityCode FROM [dbo].[City]";
        //Step 2.2: Execute Command
        //If Select Statement is there with command text --> use the method - objCmd.ExecuteReader();
        //If Insert/Update/Delete Statement is there with command text --> use the method - objCmd.ExecuteNonQuery();
        //If One R/C are return (Scalar value) is Return  with command text --> use the method - objCmd.ExecuteScalar();

        SqlDataReader objSDR = objCmd.ExecuteReader();

        //Step 2.3: Read & Display Data

        gvCity.DataSource = objSDR;
        gvCity.DataBind();

        //Step 3: Close the Connection 
        objConnection.Close();
    }

    private void DeleteCity(Int32 CityID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        try
        {
            objConnection.Open();

            SqlCommand objCmd = new SqlCommand();
            objCmd.Connection = objConnection;
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.CommandText = "PR_City_DeleteByPK";
            objCmd.Parameters.AddWithValue("@CityID", CityID);

            objCmd.ExecuteNonQuery();

            objConnection.Close();
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
        finally
        {
            objConnection.Close();
        }
    }
}