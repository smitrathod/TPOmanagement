﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class AdminPanel_City_CityAddEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FillCountryDropDownList();
            if (Request.QueryString["CityID"] != null)
            {
                // lblMessage.Text = "CityID = " + Request.QueryString["CityID"].ToString();
                LoadControls(Convert.ToInt32(Request.QueryString["CityID"]));
                lblPageHeader.Text = "City Edit";
                FillStateDropDownList();
            }
            else
            {
                lblPageHeader.Text = "City Add";

            }
        }
    }

    private void FillCountryDropDownList()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_Country_SelectDropDownList";

        SqlDataReader objSDRCountry = objCmd.ExecuteReader();
        ddlCountry.DataSource = objSDRCountry;
        ddlCountry.DataTextField = "CountryName";
        ddlCountry.DataValueField = "CountryID";
        ddlCountry.DataBind();
        if (Request.QueryString["CityID"] != null)
        {

        }
        else
        {
            ddlCountry.Items.Insert(0, "--- Select Country ---");
            ddlCountry.Items[0].Selected = true;
            ddlCountry.Items[0].Attributes["Disabled"] = "Disabled";
        }
        objConnection.Close();
    }
    private void FillStateDropDownList()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_State_SelectDropDownList";
        objCmd.Parameters.AddWithValue("@CountryID", Convert.ToInt32(ddlCountry.SelectedValue));
        SqlDataReader objSDRState = objCmd.ExecuteReader();
        ddlState.DataSource = objSDRState;
        ddlState.DataTextField = "StateName";
        ddlState.DataValueField = "StateID";
        ddlState.DataBind();
        if (Request.QueryString["CityID"] != null)
        {

        }
        else
        {
            ddlState.Items.Insert(0, "--- Select State ---");
            ddlState.Items[0].Selected = true;
            ddlState.Items[0].Attributes["Disabled"] = "Disabled";
        }
        objConnection.Close();
    }

    private void LoadControls(Int32 CityID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();

        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_City_SelectByPK";
        objCmd.Parameters.AddWithValue("@CityID", CityID);

        SqlDataReader objSDR = objCmd.ExecuteReader();

        if (objSDR.HasRows)
        {
            while (objSDR.Read())
            {
                if (!objSDR["CityName"].Equals(DBNull.Value))
                {
                    txtCityName.Text = objSDR["CityName"].ToString();
                }
                if (!objSDR["Pincode"].Equals(DBNull.Value))
                {
                    txtPincode.Text = objSDR["Pincode"].ToString();
                }
                if (!objSDR["STDCode"].Equals(DBNull.Value))
                {
                    txtSTDCode.Text = objSDR["STDCode"].ToString();
                }
                if (!objSDR["StateID"].Equals(DBNull.Value) && ddlState.SelectedValue != "0")
                {
                    ddlState.SelectedValue = objSDR["StateID"].ToString();
                }
                if (!objSDR["CountryID"].Equals(DBNull.Value) && ddlCountry.SelectedValue != "0")
                {
                    ddlCountry.SelectedValue = objSDR["CountryID"].ToString();
                }
            }
        }

        objConnection.Close();

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlString strCityName = SqlString.Null;
        SqlString strPincode = SqlString.Null;
        SqlString strSTDCode = SqlString.Null;
        SqlInt32 strStateID = SqlInt32.Null;

        if (txtCityName.Text.Trim() != "")
            strCityName = txtCityName.Text.Trim();
        if (txtPincode.Text.Trim() != "")
            strPincode = txtPincode.Text.Trim();
        if (txtSTDCode.Text.Trim() != "")
            strSTDCode = txtSTDCode.Text.Trim();
        if (ddlState.SelectedItem.Text.Trim() != "")
            strStateID = Convert.ToInt32(ddlState.SelectedValue);

        //Open the Connection
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        try
        {
            SqlCommand objCmd = objConnection.CreateCommand();
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@CityName", strCityName);
            objCmd.Parameters.AddWithValue("@Pincode", strPincode);
            objCmd.Parameters.AddWithValue("@STDCode", strSTDCode);
            objCmd.Parameters.AddWithValue("@StateID", strStateID);


            if (Request.QueryString["CityID"] == null)
            {
                objCmd.CommandText = "PR_City_Insert";
                objCmd.Parameters.AddWithValue("@CreationDate", DateTime.Now);
                objCmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
            }
            else
            {
                objCmd.CommandText = "PR_City_UpdateByPK";
                objCmd.Parameters.AddWithValue("@CityID", Request.QueryString["CityID"].ToString());
            }

            objCmd.ExecuteNonQuery();
            objConnection.Close();
            if (Request.QueryString["CityID"] == null)
            {
                lblMessage.Text = "Data Inserted Successfully....";
                txtCityName.Text = "";
                txtPincode.Text = "";
                txtSTDCode.Text = "";
                ddlState.Items.Clear();

                txtCityName.Focus();
            }
            else
            {
                Response.Redirect("~/AdminPanel/City/CityList.aspx");
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
        finally
        {
            objConnection.Close();

        }

    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
       FillStateDropDownList();
    }
}