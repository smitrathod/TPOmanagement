﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_Country_CountryAddEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["CountryID"] != null)
            {
                // lblMessage.Text = "CountryID = " + Request.QueryString["CountryID"].ToString();
                LoadControls(Convert.ToInt32(Request.QueryString["CountryID"]));
                lblPageHeader.Text = "Country Edit";
            }
            else
            {
                lblPageHeader.Text = "Country Add";
            }
        }
    }

    private void LoadControls(Int32 CountryID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();

        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_Country_SelectByPK";
        objCmd.Parameters.AddWithValue("@CountryID", CountryID);

        SqlDataReader objSDR = objCmd.ExecuteReader();

        if (objSDR.HasRows)
        {
            while (objSDR.Read())
            {
                if (!objSDR["CountryName"].Equals(DBNull.Value))
                {
                    txtCountryName.Text = objSDR["CountryName"].ToString();
                }
                if (!objSDR["CountryCode"].Equals(DBNull.Value))
                {
                    txtCountryCode.Text = objSDR["CountryCode"].ToString();
                }
            }
        }

        objConnection.Close();

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlString strCountryName = SqlString.Null;
        SqlString strCountryCode = SqlString.Null;

        if (txtCountryName.Text.Trim() != "")
            strCountryName = txtCountryName.Text.Trim();
        if (txtCountryCode.Text.Trim() != "")
            strCountryCode = txtCountryCode.Text.Trim();

        //Open the Connection
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        try
        {
            SqlCommand objCmd = objConnection.CreateCommand();
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@CountryName", strCountryName);
            objCmd.Parameters.AddWithValue("@CountryCode", strCountryCode);

            if (Request.QueryString["CountryID"] == null)
            {
                objCmd.CommandText = "PR_Country_Insert";
                objCmd.Parameters.AddWithValue("@CreationDate", DateTime.Now);
                objCmd.Parameters.AddWithValue("@UserName",Session["UserName"].ToString());
            }
            else
            {
                objCmd.CommandText = "PR_Country_UpdateByPK";
                objCmd.Parameters.AddWithValue("@CountryID", Request.QueryString["CountryID"].ToString());
            }

            objCmd.ExecuteNonQuery();
            objConnection.Close();
            if (Request.QueryString["CountryID"] == null)
            {
                lblMessage.Text = "Data Inserted Successfully....";
                txtCountryName.Text = "";
                txtCountryCode.Text = "";
                txtCountryName.Focus();
            }
            else
            {
                Response.Redirect("~/AdminPanel/Country/CountryList.aspx");
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
        finally
        {
            objConnection.Close();

        }

    }
}