﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
public partial class AdminPanel_Contact_ContactAddEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!Page.IsPostBack)
        {
            FillCountryDropDownList();
            FillContactCategoryDropDownList();
            if (Request.QueryString["ContactID"] != null)
            {
                // lblMessage.Text = "ContactID = " + Request.QueryString["ContactID"].ToString();
                LoadControls(Convert.ToInt32(Request.QueryString["ContactID"]));
                lblPageHeader.Text = "Student Edit";
                FillStateDropDownList();
                FillCityDropDownList();
            }
            else
            {
                lblPageHeader.Text = "Student Add";

            }
        }
    }

    private void FillCountryDropDownList()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_Country_SelectDropDownList";

        SqlDataReader objSDRCountry = objCmd.ExecuteReader();
        ddlCountry.DataSource = objSDRCountry;
        ddlCountry.DataTextField = "CountryName";
        ddlCountry.DataValueField = "CountryID";
        ddlCountry.DataBind();
        if (Request.QueryString["ContactID"] != null)
        {

        }
        else
        {
            ddlCountry.Items.Insert(0, "--- Select Country ---");
            ddlCountry.Items[0].Selected = true;
            ddlCountry.Items[0].Attributes["Disabled"] = "Disabled";
        }
        objConnection.Close();
    }
    private void FillStateDropDownList()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_State_SelectDropDownList";
        objCmd.Parameters.AddWithValue("@CountryID", Convert.ToInt32(ddlCountry.SelectedValue));
        SqlDataReader objSDRState = objCmd.ExecuteReader();
        ddlState.DataSource = objSDRState;
        ddlState.DataTextField = "StateName";
        ddlState.DataValueField = "StateID";
        ddlState.DataBind();
        if (Request.QueryString["ContactID"] != null)
        {

        }
        else
        {
            ddlState.Items.Insert(0, "--- Select State ---");
            ddlState.Items[0].Selected = true;
            ddlState.Items[0].Attributes["Disabled"] = "Disabled";
        }
        objConnection.Close();
    }
    private void FillCityDropDownList()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_City_SelectDropDownList";
        objCmd.Parameters.AddWithValue("@StateID", Convert.ToInt32(ddlState.SelectedValue));
        SqlDataReader objSDRCity = objCmd.ExecuteReader();
        ddlCity.DataSource = objSDRCity;
        ddlCity.DataTextField = "CityName";
        ddlCity.DataValueField = "CityID";
        ddlCity.DataBind();
        if (Request.QueryString["ContactID"] != null)
        {

        }
        else
        {
            ddlCity.Items.Insert(0, "--- Select City ---");
            ddlCity.Items[0].Selected = true;
            ddlCity.Items[0].Attributes["Disabled"] = "Disabled";
        }
        objConnection.Close();
    }
    private void FillContactCategoryDropDownList()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_ContactCategory_SelectDropDownList";

        SqlDataReader objSDRContactCategory = objCmd.ExecuteReader();
        ddlContactCategory.DataSource = objSDRContactCategory;
        ddlContactCategory.DataTextField = "ContactCategoryName";
        ddlContactCategory.DataValueField = "ContactCategoryID";
        ddlContactCategory.DataBind();
        if (Request.QueryString["ContactID"] != null)
        {

        }
        else
        {
            ddlContactCategory.Items.Insert(0, "--- Select Category ---");
            ddlContactCategory.Items[0].Selected = true;
            ddlContactCategory.Items[0].Attributes["Disabled"] = "Disabled";
        }
        objConnection.Close();
    }

    private void LoadControls(Int32 ContactID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();

        SqlCommand objCmd = objConnection.CreateCommand();
        objCmd.CommandType = CommandType.StoredProcedure;
        objCmd.CommandText = "PR_Contact_SelectByPK";
        objCmd.Parameters.AddWithValue("@ContactID", ContactID);

        SqlDataReader objSDR = objCmd.ExecuteReader();

        if (objSDR.HasRows)
        {
            while (objSDR.Read())
            {
                if (!objSDR["ContactName"].Equals(DBNull.Value))
                {
                    txtContactName.Text = objSDR["ContactName"].ToString();
                }
                if (!objSDR["Address"].Equals(DBNull.Value))
                {
                    txtAddress.Text = objSDR["Address"].ToString();
                }
                if (!objSDR["Pincode"].Equals(DBNull.Value))
                {
                    txtPincode.Text = objSDR["Pincode"].ToString();
                }
                if (!objSDR["EmailAddress"].Equals(DBNull.Value))
                {
                    txtEmailAddress.Text = objSDR["EmailAddress"].ToString();
                }
                if (!objSDR["MobileNo"].Equals(DBNull.Value))
                {
                    txtMobileNo.Text = objSDR["MobileNo"].ToString();
                }
                if (!objSDR["FaceBookID"].Equals(DBNull.Value))
                {
                    txtFaceBookID.Text = objSDR["FaceBookID"].ToString();
                }
                if (!objSDR["LinkedinID"].Equals(DBNull.Value))
                {
                    txtLinkedinID.Text = objSDR["LinkedinID"].ToString();
                }
                if (!objSDR["CountryID"].Equals(DBNull.Value))
                {
                    ddlCountry.SelectedValue = objSDR["CountryID"].ToString();
                }
                if (!objSDR["StateID"].Equals(DBNull.Value))
                {
                    ddlState.SelectedValue = objSDR["StateID"].ToString();
                }
                if (!objSDR["CityID"].Equals(DBNull.Value))
                {
                    ddlCity.SelectedValue = objSDR["CityID"].ToString();
                }
                if (!objSDR["ContactCategoryID"].Equals(DBNull.Value))
                {
                    ddlContactCategory.SelectedValue = objSDR["ContactCategoryID"].ToString();
                }
            }
        }

        objConnection.Close();

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        SqlString strContactName = SqlString.Null;
        SqlString strAddress = SqlString.Null;
        SqlString strPincode = SqlString.Null;
        SqlString strEmailAddress = SqlString.Null;
        SqlString strMobileNo = SqlString.Null;
        SqlString strFaceBookID = SqlString.Null;
        SqlString strLinkedinID = SqlString.Null;
        SqlInt32 strCountryID = SqlInt32.Null;
        SqlInt32 strStateID = SqlInt32.Null;
        SqlInt32 strCityID = SqlInt32.Null;
        SqlInt32 strContactCategoryID = SqlInt32.Null;

        if (txtContactName.Text.Trim() != "")
            strContactName = txtContactName.Text.Trim();
        if (txtAddress.Text.Trim() != "")
            strAddress = txtAddress.Text.Trim();
        if (txtPincode.Text.Trim() != "")
            strPincode = txtPincode.Text.Trim();
        if (txtEmailAddress.Text.Trim() != "")
            strEmailAddress = txtEmailAddress.Text.Trim();
        if (txtMobileNo.Text.Trim() != "")
            strMobileNo = txtMobileNo.Text.Trim();
        if (txtFaceBookID.Text.Trim() != "")
            strFaceBookID = txtFaceBookID.Text.Trim();
        if (txtLinkedinID.Text.Trim() != "")
            strLinkedinID = txtLinkedinID.Text.Trim();
        if (ddlCountry.SelectedItem.Text.Trim() != "" && ddlCountry.SelectedValue != "0")
            strCountryID = Convert.ToInt32(ddlCountry.SelectedValue);
        if (ddlState.SelectedItem.Text.Trim() != "" && ddlState.SelectedValue != "0")
            strStateID = Convert.ToInt32(ddlState.SelectedValue);
        if (ddlCity.SelectedItem.Text.Trim() != "" && ddlCity.SelectedValue != "0")
            strCityID = Convert.ToInt32(ddlCity.SelectedValue);
        if (ddlContactCategory.SelectedItem.Text.Trim() != "" && ddlContactCategory.SelectedValue != "0")
            strContactCategoryID = Convert.ToInt32(ddlContactCategory.SelectedValue);

        //Open the Connection
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        try
        {
            SqlCommand objCmd = objConnection.CreateCommand();
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@ContactName", strContactName);
            objCmd.Parameters.AddWithValue("@Address", strAddress);
            objCmd.Parameters.AddWithValue("@Pincode", strPincode);
            objCmd.Parameters.AddWithValue("@EmailAddress", strEmailAddress);
            objCmd.Parameters.AddWithValue("@MobileNo", strMobileNo);
            objCmd.Parameters.AddWithValue("@FaceBookID", strFaceBookID);
            objCmd.Parameters.AddWithValue("@LinkedinID", strLinkedinID);
            objCmd.Parameters.AddWithValue("@CountryID", strCountryID);
            objCmd.Parameters.AddWithValue("@StateID", strStateID);
            objCmd.Parameters.AddWithValue("@CityID", strCityID);
            objCmd.Parameters.AddWithValue("@ContactCategoryID", strContactCategoryID);

            if (Request.QueryString["ContactID"] == null)
            {
                objCmd.CommandText = "PR_Contact_Insert";
                objCmd.Parameters.AddWithValue("@CreationDate", DateTime.Now);
                objCmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
            }
            else
            {
                objCmd.CommandText = "PR_Contact_UpdateByPK";
                objCmd.Parameters.AddWithValue("@ContactID", Request.QueryString["ContactID"].ToString());
            }

            objCmd.ExecuteNonQuery();
            objConnection.Close();
            if (Request.QueryString["ContactID"] == null)
            {
                lblMessage.Text = "Data Inserted Successfully....";
                txtContactName.Text = "";
                txtAddress.Text = "";
                txtPincode.Text = "";
                txtEmailAddress.Text = "";
                txtMobileNo.Text = "";
                txtFaceBookID.Text = "";
                txtLinkedinID.Text = "";
                ddlCountry.Items.Clear();
                ddlState.Items.Clear();
                ddlCity.Items.Clear();
                ddlContactCategory.Items.Clear();

                txtContactName.Focus();
            }
            else
            {
                Response.Redirect("~/AdminPanel/Contact/ContactList.aspx");
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = ex.Message;
        }
        finally
        {
            objConnection.Close();

        }

    }

    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillStateDropDownList();
    }

    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillCityDropDownList();
    }
}