﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class AdminPanel_ContactCategory_ContactCategoryAddEdit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Request.QueryString["ContactCategoryID"] != null)
            {
                LoadControl(Convert.ToInt32(Request.QueryString["ContactCategoryID"]));
                lblPageHeader.Text = "Contact Category Edit";
            }
            else
            {
                lblPageHeader.Text = "Contact Category Add";
            }
        }
    }
    private void LoadControl(Int32 ContactCategoryID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();

        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.CommandText = "PR_ContactCategory_SelectByPK";
        objcmd.Parameters.AddWithValue("@ContactCategoryID", ContactCategoryID);

        SqlDataReader objSDR = objcmd.ExecuteReader();
        if (objSDR.HasRows == true)
        {
            while (objSDR.Read() == true)
            {
                if (!objSDR["ContactCategoryName"].Equals(DBNull.Value))
                {
                    txtContactCategoryName.Text = objSDR["ContactCategoryName"].ToString();

                }
            }
        }






        objConnection.Close();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {

        SqlString strContactCategoryName = SqlString.Null;

        if (txtContactCategoryName.Text.Trim() != "")
            strContactCategoryName = txtContactCategoryName.Text.Trim();

        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        // objConnection.ConnectionString = ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString;
        objConnection.Open();
        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.Parameters.AddWithValue("@ContactCategoryName", strContactCategoryName);

        if (Request.QueryString["ContactCategoryID"] == null)
        {
            objcmd.CommandText = "PR_ContactCategory_Insert";
            objcmd.Parameters.AddWithValue("@CreationDate", DateTime.Now);
            objcmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
        }
        else
        {
            objcmd.CommandText = "PR_ContactCategory_UpdateByPK";
            objcmd.Parameters.AddWithValue("@ContactCategoryID", Request.QueryString["ContactCategoryID"].ToString());

        }

        objcmd.ExecuteNonQuery();
        objConnection.Close();



        if (Request.QueryString["ContactCategoryID"] == null)
        {
            lblMessage.Text = "Data  Inserted Successfully........";
            txtContactCategoryName.Text = "";
            txtContactCategoryName.Focus();
            //lblMessage.Text = ";
        }
        else
        {
            Response.Redirect("~/AdminPanel/ContactCategory/ContactCategoryList.aspx");
        }

    }
}