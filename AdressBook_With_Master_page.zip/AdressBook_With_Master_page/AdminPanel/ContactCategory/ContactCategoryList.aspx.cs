﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPanel_ContactCategory_ContactCategoryList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        #region Session
        if (Session["UserName"] != null)
        {
            lblUserSession.Text = "Welcome, " + Session["UserName"].ToString();
        }
        if (!Page.IsPostBack)
        {
            FillContactCategoryGridView();
        }
        #endregion Session

    }
    protected void gvContactCategory_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "DeleteRecord" && e.CommandArgument != null)
        {
            DeleteContactCategory(Convert.ToInt32(e.CommandArgument));
            FillContactCategoryGridView();
        }

    }

    private void FillContactCategoryGridView()
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        //objConnection.ConnectionString = "data source=JALPESH\\SQLEXPRESS;initial catalog=AddressBook; Integrated Security=true;";
        //objConnection.ConnectionString = ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString;
        objConnection.Open();
        // lblMessage.Text ="Connection Is Now Open";
        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.CommandText = "PR_ContactCategory_SelectAll";
        objcmd.Parameters.AddWithValue("@UserName", Session["UserName"].ToString());
        SqlDataReader objSDR = objcmd.ExecuteReader();
        gvContactCategory.DataSource = objSDR;
        gvContactCategory.DataBind();
        objConnection.Close();

    }

    private void DeleteContactCategory(Int32 ContactCategoryID)
    {
        SqlConnection objConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["AddressBookConnectionString"].ConnectionString);
        objConnection.Open();
        SqlCommand objcmd = objConnection.CreateCommand();
        objcmd.CommandType = CommandType.StoredProcedure;
        objcmd.CommandText = "PR_ContactCategory_DeleteByPK";
        objcmd.Parameters.AddWithValue("@ContactCategoryID", ContactCategoryID);
        objcmd.ExecuteNonQuery();
        objConnection.Close();

    }
}